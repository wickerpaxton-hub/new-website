import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { Client, GatewayIntentBits, Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, MessageFlags } from 'discord.js';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.join(__dirname, 'data', 'applications.json');
const config = {
  port: Number(process.env.PORT || 3000),
  guildId: process.env.DISCORD_GUILD_ID,
  channelId: process.env.DISCORD_APPLICATION_CHANNEL_ID,
  memberRoleId: process.env.DISCORD_MEMBERS_ROLE_ID,
  staffRoleId: process.env.DISCORD_STAFF_ROLE_ID,
  adminUserId: process.env.DISCORD_ADMIN_USER_ID,
  token: process.env.DISCORD_BOT_TOKEN,
  turnstileSecret: process.env.TURNSTILE_SECRET_KEY,
  turnstileSite: process.env.TURNSTILE_SITE_KEY || ''
};
const required = { DISCORD_BOT_TOKEN: config.token, DISCORD_GUILD_ID: config.guildId, DISCORD_APPLICATION_CHANNEL_ID: config.channelId, DISCORD_MEMBERS_ROLE_ID: config.memberRoleId, DISCORD_STAFF_ROLE_ID: config.staffRoleId };
for (const [key, value] of Object.entries(required)) if (!value) { console.error(`Missing ${key}; configure .env first.`); process.exit(1); }

const client = new Client({ intents: [GatewayIntentBits.Guilds] });
let applications = [];
let writeQueue = Promise.resolve();
let botReady = false;
const maxPendingPerName = 1;
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', false); // Change only when deployed behind a trusted reverse proxy.
app.use(helmet({ contentSecurityPolicy: { directives: { 'default-src': ["'self'"], 'script-src': ["'self'", 'https://challenges.cloudflare.com'], 'frame-src': ['https://challenges.cloudflare.com'], 'style-src': ["'self'"], 'img-src': ["'self'", 'data:'], 'connect-src': ["'self'", 'https://challenges.cloudflare.com'], 'base-uri': ["'none'"], 'object-src': ["'none'"] } } }));
app.use(express.json({ limit: '12kb' }));
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'], index: 'index.html' }));
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 5, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many applications. Try again later.' } });

function sanitize(value, max) { return typeof value === 'string' ? value.trim().slice(0, max) : ''; }
function safeText(s) { return s.replace(/@/g, '@\u200b').replace(/`/g, '\u02cb'); }
function applicationEmbed(record) {
  const statusColor = record.status === 'approved' ? 0x25d6b4 : record.status === 'denied' ? 0xfa647d : 0x815bff;
  const status = record.status.toUpperCase();
  return new EmbedBuilder().setColor(statusColor).setTitle(`🚀 spaceCO Whitelist · ${status}`)
    .addFields(
      { name: 'Minecraft Java Username', value: safeText(record.minecraft), inline: true },
      { name: 'Discord Username', value: safeText(record.discord), inline: true },
      { name: 'Reason for joining', value: safeText(record.reason).slice(0, 1000) },
      { name: 'Application ID', value: record.id, inline: true },
      { name: 'Status', value: `${status}${record.reviewer ? ` · reviewed by <@${record.reviewer}>` : ''}`, inline: true }
    ).setTimestamp(new Date(record.createdAt)).setFooter({ text: 'spaceCO Whitelist Team' });
}
function buttons(id, disabled = false) {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`wl:approve:${id}`).setLabel('Approve').setEmoji('✅').setStyle(ButtonStyle.Success).setDisabled(disabled),
    new ButtonBuilder().setCustomId(`wl:deny:${id}`).setLabel('Deny').setEmoji('❌').setStyle(ButtonStyle.Danger).setDisabled(disabled)
  )];
}
function persist() {
  const snapshot = JSON.stringify(applications, null, 2);
  writeQueue = writeQueue.then(async () => {
    const temp = `${dbPath}.${process.pid}.tmp`;
    await fs.writeFile(temp, snapshot, { mode: 0o600 });
    await fs.rename(temp, dbPath);
  });
  return writeQueue;
}
async function verifyTurnstile(token, ip) {
  if (!config.turnstileSecret) return true;
  if (typeof token !== 'string' || token.length < 10 || token.length > 2048) return false;
  const body = new URLSearchParams({ secret: config.turnstileSecret, response: token, remoteip: ip });
  try {
    const response = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body, signal: AbortSignal.timeout(5000) });
    return (await response.json()).success === true;
  } catch { return false; }
}
app.get('/api/config', (_req, res) => res.json({ turnstileSiteKey: config.turnstileSite || null, accepting: botReady }));
app.post('/api/apply', limiter, async (req, res) => {
  if (!botReady) return res.status(503).json({ error: 'Applications temporarily unavailable. Please try again later.' });
  const minecraft = sanitize(req.body?.minecraft, 16);
  const discord = sanitize(req.body?.discord, 40);
  const reason = sanitize(req.body?.reason, 700);
  const acceptedRules = req.body?.acceptedRules === true;
  if (!/^[A-Za-z0-9_]{3,16}$/.test(minecraft)) return res.status(400).json({ error: 'Enter a valid Minecraft Java username (3–16 letters, numbers, or underscores).' });
  if (discord.length < 2 || !/^[\w.\-]{2,40}$/.test(discord)) return res.status(400).json({ error: 'Enter a valid Discord username (not a mention).' });
  if (reason.length < 20 || reason.length > 700) return res.status(400).json({ error: 'Your reason must be 20–700 characters.' });
  if (!acceptedRules) return res.status(400).json({ error: 'Please agree to follow the server rules.' });
  if (!await verifyTurnstile(req.body?.turnstileToken, req.ip)) return res.status(400).json({ error: 'Security verification failed. Try again.' });
  if (applications.filter(a => a.minecraft.toLowerCase() === minecraft.toLowerCase() && a.status === 'pending').length >= maxPendingPerName) return res.status(409).json({ error: 'That Minecraft account already has a pending application.' });

  const record = { id: crypto.randomBytes(6).toString('hex'), minecraft, discord, reason, status: 'pending', reviewer: null, createdAt: new Date().toISOString(), reviewedAt: null, messageId: null };
  // Submission and status mutation run sequentially within a single Node process; use one instance, not a server cluster.
  applications.push(record);
  try {
    await persist();
    const channel = await client.channels.fetch(config.channelId);
    if (!channel || !channel.isTextBased() || !('send' in channel)) throw new Error('Application channel not accessible');
    const message = await channel.send({
      content: `<@&${config.memberRoleId}> · New spaceCO whitelist application!`,
      allowedMentions: { roles: [config.memberRoleId] },
      embeds: [applicationEmbed(record)], components: buttons(record.id)
    });
    record.messageId = message.id;
    await persist();
    res.status(201).json({ ok: true, id: record.id, status: record.status });
  } catch (error) {
    console.error('Failed to post application:', error);
    // Keep stored pending application so an admin can recover it; do not falsely claim delivery.
    res.status(503).json({ error: 'Application saved, but Discord delivery failed. Please contact staff instead of submitting repeatedly.' });
  }
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isButton() || !interaction.customId.startsWith('wl:')) return;
  const parts = interaction.customId.split(':');
  if (parts.length !== 3 || !['approve', 'deny'].includes(parts[1])) return;
  if (interaction.guildId !== config.guildId || interaction.channelId !== config.channelId) return interaction.reply({ content: 'This button is not available here.', flags: MessageFlags.Ephemeral });
  const authorized = interaction.user.id === config.adminUserId || interaction.memberPermissions?.has(PermissionFlagsBits.Administrator) || (interaction.member?.roles?.cache?.has(config.staffRoleId) ?? false);
  if (!authorized) return interaction.reply({ content: 'Only spaceCO staff can review applications.', flags: MessageFlags.Ephemeral });
  const record = applications.find(a => a.id === parts[2]);
  if (!record) return interaction.reply({ content: 'Application not found in the database.', flags: MessageFlags.Ephemeral });
  if (record.status !== 'pending') return interaction.reply({ content: `Already ${record.status}.`, flags: MessageFlags.Ephemeral });
  await interaction.deferUpdate();
  record.status = parts[1] === 'approve' ? 'approved' : 'denied';
  record.reviewer = interaction.user.id;
  record.reviewedAt = new Date().toISOString();
  try {
    await persist();
    await interaction.editReply({ embeds: [applicationEmbed(record)], components: buttons(record.id, true) });
  } catch (error) {
    console.error('Review update failed:', error);
    await interaction.followUp({ content: 'Review update failed. Check bot logs and the stored application status.', flags: MessageFlags.Ephemeral });
  }
});

async function main() {
  await fs.mkdir(path.dirname(dbPath), { recursive: true });
  try { applications = JSON.parse(await fs.readFile(dbPath, 'utf8')); if (!Array.isArray(applications)) throw new Error('Invalid data format'); }
  catch (e) { if (e.code !== 'ENOENT') throw e; applications = []; }
  client.once(Events.ClientReady, async () => {
    const guild = await client.guilds.fetch(config.guildId).catch(() => null);
    if (!guild) { console.error('Bot cannot access configured guild.'); return; }
    botReady = true;
    console.log(`Bot logged in as ${client.user.tag} · Server ${guild.name}`);
    // Recover submissions that persisted while the Discord API was unavailable.
    const unsent = applications.filter(a => a.status === 'pending' && !a.messageId);
    if (unsent.length) console.warn(`${unsent.length} undelivered application(s). See data/applications.json and post them manually if needed.`);
  });
  await client.login(config.token);
  app.listen(config.port, () => console.log(`spaceCO website running at http://localhost:${config.port}`));
}
main().catch(err => { console.error('Startup failed:', err); process.exit(1); });
