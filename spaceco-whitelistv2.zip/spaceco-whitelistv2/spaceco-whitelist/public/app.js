const form = document.querySelector('#application-form');
const notice = document.querySelector('#notice');
const submit = document.querySelector('#submit');
const reason = document.querySelector('#reason');
reason.addEventListener('input', () => document.querySelector('#charcount').textContent = reason.value.length);
let turnstileId = null;
let siteKey = null;
async function initialize() {
  try {
    const response = await fetch('/api/config');
    const config = await response.json();
    siteKey = config.turnstileSiteKey;
    if (!config.accepting) { notice.textContent = 'Bot is not connected. Applications are temporarily unavailable.'; notice.classList.add('error'); submit.disabled = true; }
    if (siteKey) {
      const script = document.createElement('script');
      script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      script.async = true;
      script.onload = () => { turnstileId = window.turnstile.render('#turnstile-holder', { sitekey: siteKey, theme: 'dark' }); };
      document.head.appendChild(script);
    }
  } catch { notice.textContent = 'Unable to connect to application server.'; notice.classList.add('error'); submit.disabled = true; }
}
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  submit.disabled = true;
  notice.classList.remove('error');
  notice.textContent = 'Transmitting application…';
  try {
    const payload = {
      minecraft: document.querySelector('#minecraft').value,
      discord: document.querySelector('#discord').value,
      reason: reason.value,
      acceptedRules: document.querySelector('#rules-agree').checked,
      turnstileToken: siteKey && turnstileId !== null ? window.turnstile.getResponse(turnstileId) : null
    };
    const response = await fetch('/api/apply', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Application failed.');
    notice.textContent = `Application received! Your reference ID is ${data.id}. Staff will review it in Discord.`;
    form.reset();
    document.querySelector('#charcount').textContent = '0';
  } catch (error) { notice.classList.add('error'); notice.textContent = error.message; }
  finally { submit.disabled = false; if (turnstileId !== null) window.turnstile.reset(turnstileId); }
});
initialize();
