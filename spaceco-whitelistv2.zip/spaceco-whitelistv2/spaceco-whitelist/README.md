# ✦ spaceCO Whitelist — Website + Discord Bot

A space-themed Minecraft Java whitelist application website and a Discord bot that notifies **@MEMBERS** and lets staff approve/deny applications using buttons.

## Requirements

- Node.js 20 or later
- Discord server with a bot and **@MEMBERS** and **Staff** roles
- A public Node.js hosting provider for public applications (or use localhost for testing)

## Setup

1. In [Discord Developer Portal](https://discord.com/developers/applications), create an application named **spaceCO Whitelist**. Under **Bot**, copy its secret token (never post it publicly).
2. Under **OAuth2 → URL Generator**, select `bot` scope. Enable permissions **View Channels**, **Send Messages**, **Embed Links**, **Read Message History**, and **Mention @everyone, @here, and All Roles** (or make the MEMBERS role mentionable). Use the generated URL to invite it to your server. You do **not** need privileged intents or Administrator permission.
3. Turn on Discord **User Settings → Advanced → Developer Mode**. Right-click your server, application channel, MEMBERS role, and staff role to copy their IDs. For roles, use **Server Settings → Roles**, then right-click/copy ID if supported.
4. Copy `.env.example` to `.env` and fill the token, guild ID, notification channel ID, MEMBERS role ID and STAFF role ID. **The bot pings @MEMBERS inside the configured channel.** Set channel ID to your `#members` channel if desired.
5. Open a terminal in this folder and run:

   ```sh
   npm install
   npm start
   ```

6. Open `http://localhost:3000` to see the site. To accept applications from anyone on the internet, deploy the *whole Node.js app* to a Node.js host with persistent storage and HTTPS; hosting only the HTML files is not enough. Configure the same environment values in your host's secrets panel.

## How it works

1. Visitor opens the site and fills Minecraft Java username, Discord username, joining reason, and rule agreement.
2. Site validates their input, rate-limits submissions (5 per 15 minutes per IP), rejects duplicate pending Minecraft usernames, and saves a pending application to `data/applications.json`.
3. Bot posts a Discord embed in the configured application channel, pinging **@MEMBERS**. It has **Approve** and **Deny** buttons.
4. Only holders of the configured staff role, server administrators, or the optional `DISCORD_ADMIN_USER_ID` can use the review buttons.
5. Buttons update the Discord embed and persist an approved/denied status. The review buttons are disabled.

### Important notes

- **Approval does not automatically run `/whitelist add` on Minecraft.** A staff member should run `/whitelist add PlayerName` in the Minecraft server console or in game with sufficient permissions. Automatic whitelist syncing requires additional authenticated Minecraft server integration and is not included.
- **The bot does not DM applicants.** Discord usernames typed into a form cannot be trusted as proof of Discord account ownership. To verify applicants' Discord identities and notify them directly, add Discord OAuth2 login.
- **This is a single-process starter project** using a local JSON file, suitable for small servers. Use one instance with a persistent disk. Do not deploy to stateless hosting, or application data may be lost. Back up `data/applications.json`.
- If Discord posting fails, the application remains saved and the site displays a delivery failure notice; check logs and JSON data to recover manually.
- The optional Cloudflare Turnstile challenge provides extra anti-bot defense for public deployment. Set **both** `TURNSTILE_SITE_KEY` and `TURNSTILE_SECRET_KEY` to enable it. Configure your domain in Cloudflare Turnstile. If you expose the site publicly, this is recommended.
- This website and bot never need or expose your Minecraft IP, Discord invite URL, or bot token in the public web page.
- If you put the app behind a reverse proxy, correctly configure Express `trust proxy` to trust **only** that proxy for accurate IP rate-limiting.

## Quick check

Run `npm run check` to verify JavaScript syntax. Start the bot and test a sample application. Check your Discord channel and use Approve or Deny with a staff account. Test a non-staff account to confirm it cannot review.

## File layout

- `server.js` — Express API, persistent storage, Discord bot, review buttons
- `public/index.html` — spaceCO landing page and whitelist form
- `public/style.css` — space-themed visual design
- `public/app.js` — form validation, submission and status UI
- `.env.example` — configuration keys (never put real secrets here)
- `data/` — persistent application records (created at runtime)
